#include <windows.h>
#include <stdio.h>
void main()
{

    PlaySound("", NULL, SND_FILENAME | SND_ASYNC);

}